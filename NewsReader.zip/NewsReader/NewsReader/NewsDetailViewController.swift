//
//  NewsDetailViewController.swift
//  NewsReader
//
//  Created by Kuldeepsingh Chaudhari on 11/07/24.
//

import UIKit

class NewsDetailViewController: UIViewController {
    var dictArticle = [String: Any]()
    
    @IBOutlet weak var lblTitle: UILabel!
    
    @IBOutlet weak var articelImgView: UIImageView!
    @IBOutlet weak var lblDescription: UILabel!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        if let title = self.dictArticle["title"] as? String, let description = self.dictArticle["content"] as? String, let imgUrl = self.dictArticle["urlToImage"] as? String {
            self.lblTitle.text = title;
            self.lblDescription.text = description;
            if let url = URL(string: imgUrl) {
                self.articelImgView.load(url: url)
            }
        }
        // Do any additional setup after loading the view.
    }
    

    @IBAction func addToBookMark(_ sender: Any) {
        var defaultArr = [[String:Any]]()
        var defaults = UserDefaults.standard
        if let arrArticels = defaults.value(forKey: "Articels") as? [[String: Any]] {
            defaultArr = arrArticels
        }
       
        var saveDict = [String:Any]()
        saveDict["title"] = self.dictArticle["title"] ?? ""
        saveDict["content"] = self.dictArticle["content"] ?? ""
        saveDict["urlToImage"] = self.dictArticle["urlToImage"] ?? ""
        saveDict["description"] = self.dictArticle["description"] ?? ""
        defaultArr.append(saveDict)
        defaults.set(defaultArr, forKey: "Articels")
        defaults.synchronize()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension UIImageView {
    func load(url: URL) {
        DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: url) {
                if let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self?.image = image
                    }
                }
            }
        }
    }
}
