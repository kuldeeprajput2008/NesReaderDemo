//
//  BookMarkViewController.swift
//  NewsReader
//
//  Created by Kuldeepsingh Chaudhari on 11/07/24.
//

import UIKit

class BookMarkViewController: UIViewController {

    @IBOutlet weak var bookmarkTblView: UITableView!
    var bookmarkArticcles: [Any]?

    override func viewDidLoad() {
        super.viewDidLoad()
        var defaults = UserDefaults.standard
        
        if let arrArticels = defaults.value(forKey: "Articels") as? [[String:Any]] {
            self.bookmarkArticcles = arrArticels
            
        }
        let cellClass = UINib(nibName: "NewsTableViewCell", bundle: nil)
        self.bookmarkTblView.register(cellClass, forCellReuseIdentifier: "CellID")
        // Do any additional setup after loading the view.
        self.bookmarkTblView.reloadData()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension BookMarkViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.bookmarkArticcles?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellID", for: indexPath) as! NewsTableViewCell
        if let article = bookmarkArticcles?[indexPath.row] as? [String: Any], let title = article["title"] as? String, let description = article["description"] as? String{
//            cell.lblTitle.text = article["title"];
//            cell.lblDesc.text = article["description"]
            cell.lblTitle.text = title;
            cell.lblDesc.text = description
            
        }
//        cell.lblTitle.text =
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let articelVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "NewsDetailViewController") as! NewsDetailViewController
        if let dict = self.bookmarkArticcles?[indexPath.row] as? [String:Any] {
            articelVC.dictArticle = dict
        }
        self.navigationController?.pushViewController(articelVC, animated: true)
    }
}
