//
//  NewsTableViewCell.swift
//  NewsReader
//
//  Created by Kuldeepsingh Chaudhari on 11/07/24.
//

import UIKit

class NewsTableViewCell: UITableViewCell {
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblDesc: UILabel!
    
    @IBOutlet weak var vwContent: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        vwContent.layer.shadowColor = UIColor.black.cgColor
        vwContent.layer.shadowOpacity = 1
        vwContent.layer.shadowOffset = .zero
        vwContent.layer.shadowRadius = 2
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
