//
//  ViewController.swift
//  NewsReader
//
//  Created by Kuldeepsingh Chaudhari on 10/07/24.
//

import UIKit


class ViewController: UIViewController {

    @IBOutlet weak var newsTableView: UITableView!
    var newsArticcles: [Any]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.title="News List"
//        self.newsTableView.register(UITableViewCell.self, forCellReuseIdentifier: "CellID")
        let cellClass = UINib(nibName: "NewsTableViewCell", bundle: nil)
        self.newsTableView.register(cellClass, forCellReuseIdentifier: "CellID")
//        fetchNews { (newsArticcles) in
//            self.newsArticcles = newsArticcles
//            DispatchQueue.main.async {
//                self.newsTableView.reloadData()
//            }
//        }
        
        getjson()
        

    }
    
    
    @IBAction func clickedOnBookmarkList(_ sender: Any) {
        let bookmarkVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "BookMarkViewController") as! BookMarkViewController
        self.navigationController?.pushViewController(bookmarkVC, animated: true)

    }
    
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.newsArticcles?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellID", for: indexPath) as! NewsTableViewCell
        if let article = newsArticcles?[indexPath.row] as? [String: Any], let title = article["title"] as? String, let description = article["description"] as? String{
//            cell.lblTitle.text = article["title"];
//            cell.lblDesc.text = article["description"]
            cell.lblTitle.text = title;
            cell.lblDesc.text = description
            
        }
//        cell.lblTitle.text =
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let articelVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "NewsDetailViewController") as! NewsDetailViewController
        if let dict = self.newsArticcles?[indexPath.row] as? [String:Any] {
            articelVC.dictArticle = dict
        }
        self.navigationController?.pushViewController(articelVC, animated: true)
    }
}

extension ViewController {
    func getjson() {
        let urlPath = "https://newsapi.org/v2/top-headlines?country=us&category=business&apiKey=55b683b8c5ff4ee7bce9432873338328"
        let url = URL(string: urlPath)!
        let session = URLSession.shared
        let task = session.dataTask(with: url) { data, response, error in
            print("Task completed")

            guard let data = data, error == nil else {
                print(error?.localizedDescription)
                return
            }

            do {
//                if let jsonObj = try? JSONDecoder().decode(NewsArticle.self, from: data) {
//                    print("Success")
//                    DispatchQueue.main.async {
////                            self.tableData = results
////                            self.indexTableView.reloadData()
//                    }
//
//                }
                
                if let jsonResult = try JSONSerialization.jsonObject(with: data) as? [String: Any] {
                    if let results = jsonResult["articles"] as? [Any] {
                        print(results)
                        self.newsArticcles = results
                        DispatchQueue.main.async {
                            self.newsTableView.reloadData()
//                            self.tableData = results
//                            self.indexTableView.reloadData()
                        }
                    }
                }
            } catch let parseError {
                print("JSON Error \(parseError.localizedDescription)")
            }
        }

        task.resume()
    }
    func fetchNews(completionHandler: @escaping([Article]) -> Void){
        let url = URL(string: "https://newsapi.org/v2/top-headlines?country=us&category=business&apiKey=55b683b8c5ff4ee7bce9432873338328")!

        let task = URLSession.shared.dataTask(with: url, completionHandler:{(data,response,error) in
            guard let dataObj = data, error == nil else {
                       print(error?.localizedDescription)
                       return
                   }
            
            if let newsData = try? JSONDecoder().decode(NewsArticle.self, from: dataObj) {
                print("Parsing Success")
                completionHandler(newsData.articles)
            }
            

//            guard let data = data else { return }
//
//            if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
//
//            }

//            if let data = data, let newsData = try? JSONDecoder().decode(NewsArticle.self, from: data) {
//                let str = String(decoding: data, as: UTF8.self)
//                print("data = \(str)")
//
//                completionHandler(newsData.articles)
//            }
        })

        task.resume();
    }
}

struct NewsArticle: Codable {
    let status: String
    let totalResults: Double
    let articles: [Article]
    
}

struct Article:Codable {
    let source: Source
    let author: String
    let title: String
    let description: String
    let url: URL
    let urlToImage: URL
    let publishedAt: String
}

struct Source: Codable {
    let id: String
    let name: String
}
//   func callNewsFeeds() {
//       let url = URL(string: "")!
//
//       let task = URLSession.shared.dataTask(with: url, completionHandler: { (data, response, error) in
//         if let error = error {
//           print("Error with fetching films: \(error)")
//           return
//         }
//
//         guard let httpResponse = response as? HTTPURLResponse,
//               (200...299).contains(httpResponse.statusCode) else {
//           print("Error with the response, unexpected status code: \(response)")
//           return
//         }
//
//         if let data = data,
//           let filmSummary = try? JSONDecoder().decode(FilmSummary.self, from: data) {
//           completionHandler(filmSummary.results ?? [])
//         }
//       })
//       task.resume()
//     }


